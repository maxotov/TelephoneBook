-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 11 2014 г., 06:00
-- Версия сервера: 5.5.16
-- Версия PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `phone_book`
--

-- --------------------------------------------------------

--
-- Структура таблицы `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fathername` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `street_id` int(11) NOT NULL,
  `flat` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lastname` (`lastname`,`phone`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `contacts`
--

INSERT INTO `contacts` (`id`, `lastname`, `firstname`, `fathername`, `phone`, `street_id`, `flat`) VALUES
(1, 'Мақсотов', 'Айбол', 'Куанышович', '87774174086', 6, 67),
(3, 'Мақымова', 'Аягүл', 'Қуанышқызы', '87016878697', 4, 14),
(4, 'Рысқали', 'Асылжан', 'Асылжанұлы', '87715699699', 2, 56),
(5, 'Альжанова', 'Венера', 'Жардемовна', '87775654175', 6, 66),
(7, 'Иванов', 'Сергей', 'Иванович', '87751236989', 6, 9),
(8, 'Ханов', 'Асылхан', 'Асылханұлы', '87714565689', 4, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `streets`
--

CREATE TABLE IF NOT EXISTS `streets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `streets`
--

INSERT INTO `streets` (`id`, `name`) VALUES
(1, 'Абая'),
(2, 'Республика'),
(3, 'Мирзояна'),
(4, 'Кенесары'),
(5, 'Ауезова'),
(6, 'Сейфуллина'),
(7, 'Сарайшык'),
(8, 'Тәуелсіздік'),
(9, 'Манас'),
(10, 'Желтоқсан');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
